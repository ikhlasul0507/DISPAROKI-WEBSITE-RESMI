<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	<style type="text/css">

	::selection { background-color: black; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: black;
	}

	
	h1 {
		color: red;
		font-size: 60px;
	}
	.blink {
                        color: red;
                        animation: blink-animation 1s steps(5, start) infinite;
                        -webkit-animation: blink-animation 1s steps(5, start) infinite;
                      }
                      @keyframes blink-animation {
                        to {
                          visibility: hidden;
                        }
                      }
                      @-webkit-keyframes blink-animation {
                        to {
                          visibility: hidden;
                        }
                      }

	

	</style>
</head>
<body>


	<center>
	<h1>Opss...</h1>

	
		<h1>WARNING</h1>
		<h1 class="blink">YOUR ACCESS IS WRONG !!! 
			<br>YOU CAN CALLED ADMIN </h1>
			<hr><marquee><h1>---------------------ATTENTION  !---------------------</h1></marquee><hr>
	


</body>
</html>