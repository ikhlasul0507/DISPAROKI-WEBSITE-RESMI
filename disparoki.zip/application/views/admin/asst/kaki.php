</div>
 
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2020-1
    </div>
    <strong>Copyright &copy; <?= date('Y'); ?> Ikhlasul Amal.</strong> All rights
    reserved.
  </footer>

 
  <aside class="control-sidebar control-sidebar-dark">
 
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
   
    <div class="tab-content">
     
      <div class="tab-pane" id="control-sidebar-home-tab">
       
     
      </div>
   
      <div class="tab-pane" id="control-sidebar-settings-tab">
    
      </div>
     
    </div>
  </aside>
 
  <div class="control-sidebar-bg"></div>
</div>

